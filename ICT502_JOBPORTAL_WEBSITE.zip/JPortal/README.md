#### How to import->

1. create a database on your localhost named as `jportal`;
2. then copy the repo to your htdocs folder and visit using this URL on your localhost http://localhost/JPortal/
3. then import the sql (which is inside the sql directory) file on phpmyadmin

to access admin panel:
http://localhost/JPortal/admin

Email: admin
Password: admin123
